const ghost1 = document.getElementById('ghost1');
const rc = rough.svg(ghost1);
// rc.rectangle(10, 10, 200, 200);
ghost1.setAttribute("viewBox", "0 0 200 150");
   
// shape for ghost 1 
ghost1.appendChild(rc.path("m 22.523077,79.938462 c 0,0 16.03027,-39.611366 20.307692,-52.43077 C 46.498319,8.522083 68.876874,5.1447796 76.646154,24 85.125295,40.395241 96.030769,87.307692 97.030769,78.307692 Z",
    {
      stroke:'none',
      fill:'#ADD8E6',
      fillWeight:'0.8',
      fillStyle:'dots',
      roughness:4
    }));
ghost1.appendChild(rc.circle(60,55,6,
{
  strokeWidth:'0.4',
  fill:'white',
  fillStyle:'solid',
  roughness:0.3
}));
// Left eye for ghost 1
ghost1.appendChild(rc.circle(52,42,15,{
  strokeWidth:'0.5',
  roughness:0.3,
  fill:'white',
  fillStyle:"solid"
}))
//Left pupil for ghost 1
ghost1.appendChild(rc.circle(52,42,3,{
  strokeWidth:'0.5',
  roughness:0.5,
  fill:'black',
  fillStyle:"solid"
}))
//Right pupil for ghost 1
ghost1.appendChild(rc.circle(68,42,15,{
  strokeWidth:'0.5',
  roughness:0.3,
  fill:'white',
  fillStyle:"solid"
}))
//Right pupil for ghost 1
ghost1.appendChild(rc.circle(68,42,3,{
  strokeWidth:'0.5',
  roughness:0.5,
  fill:'black',
  fillStyle:"solid"
}))



const ghost2 = document.getElementById('ghost2');
const rc2 = rough.svg(ghost2);
ghost2.setAttribute("viewBox", "0 0 200 150");

// Shape for ghost 2
ghost2.appendChild(rc.path("M 77.353846,111.87692 C 73.567541,96.816792 27.567928,82.323072 24,65.907692 20.462271,49.63125 29.124008,23.800682 43.56923,15.507693 56.996984,7.7988311 82.421161,3.6224252 92.86154,16.061539 c 7.32285,8.724765 11.56143,44.268862 1.280773,53.32895 C 78.895941,82.826735 78.261765,115.48819 77.353846,111.87692 Z",
{
  stroke:'none',
  fill:'#977FD7',
  fillWeight:'0.9',
  fillStyle:'dots',
  roughness:0.8
}));
ghost2.appendChild(rc.path("M 41.169231,61.292307 80.676923,53.538461",
{
  strokeWidth:'0.8',
  roughness:0.4,
  fill:'white',
  fillStyle:'solid',
  roughness:0.5
}));
ghost2.appendChild(rc.path("m 41.169231,61.292307 7.015384,7.015385 2.953846,-9.046154 z",
{
  strokeWidth:'0.8',
  roughness:0.4,
  fill:'white',
  fillStyle:'solid',
  roughness:0.5
}));
//mouth
ghost2.appendChild(rc.path("M 69.599999,55.753846 78.276923,62.4 l 2.4,-8.861539 z",
{
  strokeWidth:'0.8',
  roughness:0.4,
  fill:'white',
  fillStyle:'solid',
  roughness:0.5
}));
ghost2.appendChild(rc.circle(62,42,20,{
  strokeWidth:'0.8',
  roughness:0.4,
  fill:'white',
  fillStyle:"solid"
}))
ghost2.appendChild(rc.circle(62,42,3,{
  strokeWidth:'0.8',
  roughness:0.8,
  fill:'black',
  fillStyle:"solid"
}))

const ghost3 = document.getElementById('ghost3');
const rc3 = rough.svg(ghost1);
ghost3.setAttribute("viewBox", "0 0 150 150");
ghost3.appendChild(rc.path("M 90.276923,93.230769 C 71.909141,92.503159 37.786189,68.418113 35.815385,51.876923 29.957585,57.115131 15.552838,46.41389 11.446154,40.615385 6.5963892,33.767674 24.553846,36.184616 24.553846,36.184616 c 0,0 -4.533198,-19.23986 0.184616,-25.292308 C 30.362693,3.6770226 41.28272,0.92578181 50.03077,17.16923 53.430646,23.482146 64.899954,1.6065367 66.092308,8.6769231 67.525822,17.177334 61.003135,24.890286 63.876924,30.461538 94.243634,46.536084 58.15223,75.964532 90.276923,93.230769 Z",
{
  // stroke:'none',
  fill:'#35ABAF',
  fillWeight:'0.9',
  fillStyle:'hachure',
  roughness:0.8
}));
ghost3.appendChild(rc.circle(38,22,13,{
  strokeWidth:'0.8',
  roughness:0.4,
  fill:'white',
  fillStyle:"solid"
}))

ghost3.appendChild(rc.circle(38,22,3,{
  strokeWidth:'0.8',
  roughness:0.8,
  fill:'black',
  fillStyle:"solid"
}))


const ghost4 = document.getElementById('ghost4');
const rc4 = rough.svg(ghost4);
ghost4.setAttribute("viewBox", "0 0 150 150");
ghost4.appendChild(rc.path("M 29.907692,80.492308 C 21.665398,71.170539 19.725197,54.218112 25.846154,43.384615 31.182572,33.939675 39.217423,24.869372 50.030769,24 c 9.108398,-0.732297 25.065319,0.809218 31.938462,6.830769 6.99096,6.12477 18.009022,24.798514 14.953846,35.261539 C 92.905186,79.85233 73.815496,85.440041 59.630769,87.507692 49.557306,88.97606 36.650857,88.118611 29.907692,80.492308 Z",
{
  // stroke:'none',
  strokeWidth:'0.9',
  fill:'#F26936',
  // fillWeight:'0.8',
  fillStyle:'dashed',
  roughness:0.4
}));

ghost4.appendChild(rc.circle(42,53,13,{
  strokeWidth:'0.4',
  roughness:0.4,
  fill:'white',
  fillStyle:"solid"
}))

ghost4.appendChild(rc.circle(42,53,3,{
  strokeWidth:'0.4',
  roughness:0.8,
  fill:'black',
  fillStyle:"solid"
}))
ghost4.appendChild(rc.circle(66,53,13,{
  strokeWidth:'0.4',
  roughness:0.4,
  fill:'white',
  fillStyle:"solid"
}))

ghost4.appendChild(rc.circle(66,53,3,{
  strokeWidth:'0.4',
  roughness:0.8,
  fill:'black',
  fillStyle:"solid"
}))
ghost4.appendChild(rc.circle(53,48,17,{
  strokeWidth:'0.4',
  roughness:0.4,
  fill:'white',
  fillStyle:"solid"
}))

ghost4.appendChild(rc.circle(53,48,3,{
  strokeWidth:'0.8',
  roughness:0.8,
  fill:'black',
  fillStyle:"solid"
}))
ghost4.appendChild(rc.path("m 36.369231,66.276923 c 0,0 2.065594,-7.882941 5.169231,-7.753846 2.669482,0.111036 3.876923,7.015385 3.876923,7.015385 0,0 2.935372,-7.307803 5.907692,-6.83077 2.369675,0.380314 2.769231,6.646154 2.769231,6.646154 0,0 3.631235,-6.719576 6.646154,-6.276923 2.318459,0.340398 3.507692,6.092308 3.507692,6.092308 0,0 2.067662,-6.091462 4.615384,-6.092308 2.240034,-7.43e-4 3.507693,6.646154 3.507693,6.646154 0,0 1.251689,-7.321831 3.507692,-7.384615 2.533328,-0.0705 3.692308,6.646153 3.692308,6.646153",
{
  strokeWidth:'0.4',
  roughness:0.4,
  fill:'white',
  fillStyle:'solid',
  roughness:0.3
}));
ghost4.appendChild(rc.path("m 36.369231,66.276923 c 0,0 14.827827,0.596335 22.153846,0.369231 7.111931,-0.220468 21.046154,-1.661539 21.046154,-1.661539",
{
  strokeWidth:'0.4',
  roughness:0.4,
  fill:'white',
  fillStyle:'solid',
  roughness:0.3
}));

const sun = document.getElementById('sun');
const rc5 = rough.svg(sun);
sun.setAttribute("viewBox", "0 0 150 350");
// sun.appendChild(rc5)
sun.appendChild(rc.circle(56,45,23,{
  stroke:'none',
  strokeWidth:'0.8',
  roughness:0.8,
  fill:'#F47421',
  fillStyle:"solid"
}))
sun.appendChild(rc5.path("m 47.870601,23.817587 c -0.532432,2.791122 1.721974,3.594296 3.340149,6.951113 0.705487,1.463494 3.681317,-0.263635 4.100776,-1.833215 0.735159,-2.750903 -0.307448,-7.174292 -3.037304,-7.984119 -2.092529,-0.62076 -3.994633,0.722218 -4.403621,2.866221 z"
,{
  stroke:'none',
  fill:'#FFC120',
  fillStyle:"solid",
  strokeWidth:'0.4',
  roughness:0.2
}));
sun.appendChild(rc5.path("m 65.922701,18.378667 c -2.417382,1.837223 -2.120261,5.292875 -4.096321,10.248167 -0.861517,2.160393 1.725534,4.240749 3.134443,3.353536 2.469305,-1.554966 5.522556,-6.759938 5.034629,-10.799519 -0.374012,-3.096483 -2.215834,-4.213445 -4.072751,-2.802184 z"
,{
  stroke:'none',
  fill:'#FFC120',
  fillStyle:"solid",
  strokeWidth:'0.4',
  roughness:0.2
}));
sun.appendChild(rc5.path(d="m 74.509724,31.539464 c -2.855784,0.07978 -2.964109,2.212512 -5.729421,4.287579 -1.205611,0.904682 1.345734,3.174291 2.987248,3.234621 2.876982,0.105737 6.843844,-1.673744 6.817709,-4.224404 -0.02003,-1.955171 -1.881864,-3.359082 -4.075536,-3.297796 z"
,{
  stroke:'none',
  fill:'#FFC120',
  fillStyle:"solid",
  strokeWidth:'0.4',
  roughness:0.2
}));
sun.appendChild(rc5.path(d="m 82.565823,43.368174 c -3.307604,-1.607499 -5.233884,0.165825 -10.125994,0.329957 -2.132848,0.07156 -1.157239,3.523883 0.654193,4.53934 3.174785,1.77973 9.18022,2.575442 11.307335,0.363233 1.63051,-1.695736 0.705201,-3.997727 -1.835534,-5.23253 z"
,{
  stroke:'none',
  fill:'#FFC120',
  fillStyle:"solid",
  strokeWidth:'0.4',
  roughness:0.2
}));
sun.appendChild(rc5.path(d="m 67.112192,57.591703 c 0.888691,2.698902 3.249651,2.307364 6.293315,4.457438 1.326967,0.937382 3.09104,-2.016696 2.696258,-3.592663 -0.691912,-2.762099 -3.749797,-6.124053 -6.529719,-5.507643 -2.130908,0.472499 -3.142502,2.569703 -2.459854,4.642868 z"
,{
  stroke:'none',
  fill:'#FFC120',
  fillStyle:"solid",
  strokeWidth:'0.4',
  roughness:0.2
}));
sun.appendChild(rc5.path(d="m 65.959991,65.995647 c 0.198224,-2.834528 -2.135418,-3.365136 -4.13965,-6.506755 -0.8738,-1.369671 -3.624211,0.69764 -3.854885,2.305842 -0.404288,2.818597 1.154705,7.08743 3.961241,7.568353 2.151306,0.368644 3.881027,-1.190093 4.033294,-3.36744 z"
,{
  stroke:'none',
  fill:'#FFC120',
  fillStyle:"solid",
  strokeWidth:'0.4',
  roughness:0.2
}));
sun.appendChild(rc5.path(d="m 48.678818,73.533637 c 2.182857,-2.110512 1.478685,-5.50668 2.854152,-10.66108 0.599674,-2.247198 -2.215492,-4.006622 -3.509448,-2.958837 -2.267831,1.836388 -4.683352,7.366248 -3.720579,11.319645 0.737997,3.030421 2.69911,3.92146 4.375875,2.300272 z"
,{
  stroke:'none',
  fill:'#FFC120',
  fillStyle:"solid",
  strokeWidth:'0.4',
  roughness:0.2
}));
sun.appendChild(rc5.path(d="m 38.593988,61.48209 c 2.826252,-0.417335 2.681305,-2.547892 5.181483,-4.935769 1.090019,-1.041061 -1.712096,-2.992632 -3.349207,-2.858188 -2.869265,0.235634 -6.597539,2.472266 -6.269596,5.001891 0.251376,1.939047 2.266334,3.112648 4.43732,2.792066 z"
,{
  stroke:'none',
  fill:'#FFC120',
  fillStyle:"solid",
  strokeWidth:'0.4',
  roughness:0.2
}));
sun.appendChild(rc5.path(d="m 29.194064,50.690403 c 3.474664,1.20458 5.177437,-0.784337 10.015704,-1.526529 2.109374,-0.323581 0.731883,-3.63611 -1.187038,-4.429956 -3.363171,-1.391326 -9.420575,-1.470412 -11.270809,0.978081 -1.41827,1.876859 -0.226919,4.053103 2.442143,4.978404 z"
,{
  stroke:'none',
  fill:'#FFC120',
  fillStyle:"solid",
  strokeWidth:'0.4',
  roughness:0.2
}));
sun.appendChild(rc5.path(d="m 42.854967,34.737247 c -1.201983,-2.574699 -3.49998,-1.906384 -6.776799,-3.680973 -1.428617,-0.773679 -2.830526,2.368483 -2.251931,3.886624 1.014071,2.66075 4.448495,5.637011 7.135883,4.695801 2.059977,-0.72147 2.816151,-2.923693 1.892847,-4.901452 z"
,{
  stroke:'none',
  fill:'#FFC120',
  fillStyle:"solid",
  strokeWidth:'0.4',
  roughness:0.2
}));

